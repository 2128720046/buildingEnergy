import type { AssetInput } from '@pascal-app/core'
import {
  type AnyNodeId,
  type CeilingEvent,
  emitter,
  type GridEvent,
  getScaledDimensions,
  type ItemEvent,
  resolveLevelId,
  type ShelfEvent,
  sceneRegistry,
  spatialGridManager,
  useLiveTransforms,
  useScene,
  useSpatialQuery,
  type WallEvent,
  type WallNode,
} from '@pascal-app/core'
import { useViewer } from '@pascal-app/viewer'
import { Html } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  BufferGeometry,
  Euler,
  Float32BufferAttribute,
  type Group,
  type LineSegments,
  type Mesh,
  PlaneGeometry,
  Quaternion,
  Vector3,
} from 'three'
import { distance, smoothstep, uv, vec2 } from 'three/tsl'
import { LineBasicNodeMaterial, MeshBasicNodeMaterial } from 'three/webgpu'
import { EDITOR_LAYER } from '../../../lib/constants'
import { sfxEmitter } from '../../../lib/sfx-bus'
import useEditor from '../../../store/use-editor'
import { getGridAlignedDimensions, snapToGrid, snapUpToGridStep } from './placement-math'
import {
  ceilingStrategy,
  checkCanPlace,
  floorStrategy,
  itemSurfaceStrategy,
  shelfSurfaceStrategy,
  wallStrategy,
} from './placement-strategies'
import type { PlacementState, TransitionResult } from './placement-types'
import type { DraftNodeHandle } from './use-draft-node'

const DEFAULT_DIMENSIONS: [number, number, number] = [1, 1, 1]

function formatMeasurement(value: number, unit: 'metric' | 'imperial') {
  if (unit === 'imperial') {
    const feet = value * 3.280_84
    const wholeFeet = Math.floor(feet)
    const inches = Math.round((feet - wholeFeet) * 12)
    if (inches === 12) return `${wholeFeet + 1}'0"`
    return `${wholeFeet}'${inches}"`
  }
  return `${Number.parseFloat(value.toFixed(2))}m`
}

type PreviewBounds = {
  min: [number, number, number]
  max: [number, number, number]
  dimensions: [number, number, number]
  center: [number, number, number]
}

/**
 * Expand `bounds` outward so each axis is rounded up to the active grid step.
 * The wireframe stays centered on the original bounds centre on each axis we
 * expand, so an off-centre mesh bbox stays off-centre. Wall-side items keep
 * `max.z = 0` (flush with the wall plane); the bottom (`min.y`) is preserved
 * so the box still sits on the floor / attachment plane.
 *
 * Floor / ceiling / item-surface: X and Z expand; Y stays exact.
 * Wall / wall-side: X and Y expand; Z stays exact.
 */
function expandBoundsToGrid(
  bounds: PreviewBounds,
  attachTo: AssetInput['attachTo'] | null | undefined,
  step: number,
): PreviewBounds {
  const [w, h, d] = bounds.dimensions
  const [cx, , cz] = bounds.center
  const onWall = attachTo === 'wall' || attachTo === 'wall-side'
  const expandedW = snapUpToGridStep(w, step)
  const expandedH = onWall ? snapUpToGridStep(h, step) : h
  const expandedD = onWall ? d : snapUpToGridStep(d, step)

  const minX = cx - expandedW / 2
  const maxX = cx + expandedW / 2
  const minY = bounds.min[1]
  const maxY = minY + expandedH

  let minZ: number
  let maxZ: number
  let newCz: number
  if (attachTo === 'wall-side') {
    maxZ = 0
    minZ = -expandedD
    newCz = -expandedD / 2
  } else {
    minZ = cz - expandedD / 2
    maxZ = cz + expandedD / 2
    newCz = cz
  }

  return {
    min: [minX, minY, minZ],
    max: [maxX, maxY, maxZ],
    dimensions: [expandedW, expandedH, expandedD],
    center: [cx, (minY + maxY) / 2, newCz],
  }
}

function getFallbackPreviewBounds(
  item: import('@pascal-app/core').ItemNode | null,
  asset: AssetInput | null | undefined,
  attachTo: AssetInput['attachTo'] | null | undefined,
): PreviewBounds {
  const dims = item ? getScaledDimensions(item) : (asset?.dimensions ?? DEFAULT_DIMENSIONS)
  return {
    min: [-dims[0] / 2, 0, attachTo === 'wall-side' ? -dims[2] : -dims[2] / 2],
    max: [dims[0] / 2, dims[1], attachTo === 'wall-side' ? 0 : dims[2] / 2],
    dimensions: dims,
    center: [0, dims[1] / 2, attachTo === 'wall-side' ? -dims[2] / 2 : 0],
  }
}

function createLineGeometry(points: number[] = [0, 0, 0, 0, 0, 0]): BufferGeometry {
  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new Float32BufferAttribute(points, 3))
  return geometry
}

function getBoxEdgePoints(bounds: PreviewBounds): number[] {
  const [width, height, depth] = bounds.dimensions
  const [centerX, centerY, centerZ] = bounds.center
  const minX = centerX - width / 2
  const maxX = centerX + width / 2
  const minY = centerY - height / 2
  const maxY = centerY + height / 2
  const minZ = centerZ - depth / 2
  const maxZ = centerZ + depth / 2

  return [
    minX,
    minY,
    minZ,
    maxX,
    minY,
    minZ,
    maxX,
    minY,
    minZ,
    maxX,
    minY,
    maxZ,
    maxX,
    minY,
    maxZ,
    minX,
    minY,
    maxZ,
    minX,
    minY,
    maxZ,
    minX,
    minY,
    minZ,

    minX,
    maxY,
    minZ,
    maxX,
    maxY,
    minZ,
    maxX,
    maxY,
    minZ,
    maxX,
    maxY,
    maxZ,
    maxX,
    maxY,
    maxZ,
    minX,
    maxY,
    maxZ,
    minX,
    maxY,
    maxZ,
    minX,
    maxY,
    minZ,

    minX,
    minY,
    minZ,
    minX,
    maxY,
    minZ,
    maxX,
    minY,
    minZ,
    maxX,
    maxY,
    minZ,
    maxX,
    minY,
    maxZ,
    maxX,
    maxY,
    maxZ,
    minX,
    minY,
    maxZ,
    minX,
    maxY,
    maxZ,
  ]
}

function updateLineGeometry(ref: React.RefObject<LineSegments>, points: number[]) {
  const geometry = ref.current?.geometry
  if (!geometry) return

  const attribute = geometry.getAttribute('position') as Float32BufferAttribute | undefined
  if (!attribute || attribute.array.length !== points.length) {
    geometry.setAttribute('position', new Float32BufferAttribute(points, 3))
  } else {
    attribute.set(points)
    attribute.needsUpdate = true
  }
  geometry.computeBoundingSphere()
}

// Shared materials for placement cursor - we just change colors, not swap materials
// Note: EdgesGeometry doesn't work with dashed lines, so using solid lines
const edgeMaterial = new LineBasicNodeMaterial({
  color: 0xef_44_44, // red-500 (invalid)
  linewidth: 3,
  depthTest: false,
  depthWrite: false,
})

const measurementMaterial = new LineBasicNodeMaterial({
  color: 0x0f_17_2a,
  linewidth: 2,
  depthTest: false,
  depthWrite: false,
})

const basePlaneMaterial = new MeshBasicNodeMaterial({
  color: 0xef_44_44, // red-500 (invalid)
  transparent: true,
  depthTest: false,
  depthWrite: false,
})

// Create radial opacity: transparent in center, opaque at edges
const center = vec2(0.5, 0.5)
const dist = distance(uv(), center)
const radialOpacity = smoothstep(0, 0.7, dist).mul(0.6)
basePlaneMaterial.opacityNode = radialOpacity

export interface PlacementCoordinatorConfig {
  asset: AssetInput | null
  draftNode: DraftNodeHandle
  initDraft: (gridPosition: Vector3) => void
  onCommitted: () => boolean
  onCancel?: () => void
  initialState?: PlacementState
  /** Scale to use when lazily creating a draft (e.g. for wall/ceiling duplicates). Defaults to [1,1,1]. */
  defaultScale?: [number, number, number]
}

export function usePlacementCoordinator(config: PlacementCoordinatorConfig): React.ReactNode {
  const cursorGroupRef = useRef<Group>(null!)
  const edgesRef = useRef<LineSegments>(null!)
  const measurementWidthRef = useRef<LineSegments>(null!)
  const measurementDepthRef = useRef<LineSegments>(null!)
  const measurementHeightRef = useRef<LineSegments>(null!)
  const basePlaneRef = useRef<Mesh>(null!)
  const gridPosition = useRef(new Vector3(0, 0, 0))
  const lastRawPos = useRef(new Vector3(0, 0, 0))
  const lastWallDirtyAtRef = useRef(new Map<string, number>())
  const placementState = useRef<PlacementState>(
    config.initialState ?? {
      surface: 'floor',
      wallId: null,
      ceilingId: null,
      surfaceItemId: null,
      shelfId: null,
    },
  )
  const shiftFreeRef = useRef(false)
  const previewBoundsSignatureRef = useRef<string | null>(null)
  // Goes true the first time a 3D pointer event drives this coordinator.
  // The per-frame mesh-position lerp below is only useful for that path;
  // when the move is being driven externally (2D `FloorplanRegistryMoveOverlay`
  // writing scene.position directly), the lerp fights React's render and
  // pulls the rendered item back toward its pre-move position. Gating
  // the lerp on this flag keeps 3D placement smooth without hijacking
  // 2D drags that share the same draft.
  const has3DPointerDrivenMoveRef = useRef(false)
  const [dimensionBounds, setDimensionBounds] = useState<PreviewBounds | null>(null)

  // Store config callbacks in refs to avoid re-running effect when they change
  const configRef = useRef(config)
  configRef.current = config

  const { canPlaceOnFloor, canPlaceOnWall, canPlaceOnCeiling } = useSpatialQuery()
  const { asset, draftNode } = config
  const unit = useViewer((state) => state.unit)
  const gridSnapStep = useEditor((s) => s.gridSnapStep)
  const updatePreviewGeometry = useCallback((bounds: PreviewBounds) => {
    const [width, height, depth] = bounds.dimensions
    const [centerX, centerY, centerZ] = bounds.center
    const signature = `${width.toFixed(4)}:${height.toFixed(4)}:${depth.toFixed(4)}:${centerX.toFixed(4)}:${centerY.toFixed(4)}:${centerZ.toFixed(4)}`

    if (previewBoundsSignatureRef.current === signature) return
    previewBoundsSignatureRef.current = signature

    const nextBasePlaneGeometry = new PlaneGeometry(width, depth)
    nextBasePlaneGeometry.rotateX(-Math.PI / 2)
    nextBasePlaneGeometry.translate(centerX, 0.01, centerZ)

    updateLineGeometry(edgesRef, getBoxEdgePoints(bounds))

    const oldBasePlaneGeometry = basePlaneRef.current.geometry
    basePlaneRef.current.geometry = nextBasePlaneGeometry
    oldBasePlaneGeometry.dispose()
  }, [])

  const updateDimensionGuides = useCallback((bounds: PreviewBounds) => {
    setDimensionBounds((current) => {
      if (
        current &&
        current.dimensions[0] === bounds.dimensions[0] &&
        current.dimensions[1] === bounds.dimensions[1] &&
        current.dimensions[2] === bounds.dimensions[2] &&
        current.center[0] === bounds.center[0] &&
        current.center[1] === bounds.center[1] &&
        current.center[2] === bounds.center[2]
      ) {
        return current
      }
      return bounds
    })

    const [width, , depth] = bounds.dimensions
    const [centerX, , centerZ] = bounds.center
    const minX = centerX - width / 2
    const maxX = centerX + width / 2
    const minZ = centerZ - depth / 2
    const maxZ = centerZ + depth / 2
    const guideOffset = 0.18
    const tick = 0.08
    const y = 0.02

    const widthPoints = [
      minX,
      y,
      maxZ + guideOffset,
      maxX,
      y,
      maxZ + guideOffset,

      minX,
      y,
      maxZ + guideOffset - tick,
      minX,
      y,
      maxZ + guideOffset + tick,

      maxX,
      y,
      maxZ + guideOffset - tick,
      maxX,
      y,
      maxZ + guideOffset + tick,
    ]

    const depthPoints = [
      maxX + guideOffset,
      y,
      minZ,
      maxX + guideOffset,
      y,
      maxZ,

      maxX + guideOffset - tick,
      y,
      minZ,
      maxX + guideOffset + tick,
      y,
      minZ,

      maxX + guideOffset - tick,
      y,
      maxZ,
      maxX + guideOffset + tick,
      y,
      maxZ,
    ]

    const heightPoints = [
      minX - guideOffset,
      0,
      minZ,
      minX - guideOffset,
      bounds.dimensions[1],
      minZ,

      minX - guideOffset - tick,
      0,
      minZ,
      minX - guideOffset + tick,
      0,
      minZ,

      minX - guideOffset - tick,
      bounds.dimensions[1],
      minZ,
      minX - guideOffset + tick,
      bounds.dimensions[1],
      minZ,
    ]

    const applyPoints = (ref: React.RefObject<LineSegments>, points: number[]) => {
      updateLineGeometry(ref, points)
    }

    applyPoints(measurementWidthRef, widthPoints)
    applyPoints(measurementDepthRef, depthPoints)
    applyPoints(measurementHeightRef, heightPoints)
  }, [])

  useEffect(() => {
    if (!asset) return
    useScene.temporal.getState().pause()

    const validators = { canPlaceOnFloor, canPlaceOnWall, canPlaceOnCeiling }

    // Reset placement state
    placementState.current = configRef.current.initialState ?? {
      surface: 'floor',
      wallId: null,
      ceilingId: null,
      surfaceItemId: null,
      shelfId: null,
    }
    if (!asset.attachTo && placementState.current.surface === 'floor') {
      gridPosition.current.y = 0
      cursorGroupRef.current.position.y = 0
    }

    // ---- Helpers ----

    const getContext = () => ({
      asset,
      levelId: useViewer.getState().selection.levelId,
      draftItem: draftNode.current,
      gridPosition: gridPosition.current,
      state: { ...placementState.current },
      currentCursorRotationY: cursorGroupRef.current.rotation.y,
    })

    const getActiveValidators = () =>
      shiftFreeRef.current
        ? {
            canPlaceOnFloor: () => ({ valid: true }),
            canPlaceOnWall: () => ({ valid: true }),
            canPlaceOnCeiling: () => ({ valid: true }),
          }
        : validators

    const revalidate = (): boolean => {
      const placeable = shiftFreeRef.current || checkCanPlace(getContext(), validators)
      const color = placeable ? 0x22_c5_5e : 0xef_44_44 // green-500 : red-500
      edgeMaterial.color.setHex(color)
      basePlaneMaterial.color.setHex(color)
      return placeable
    }

    // Tool visuals are rendered inside the building-local ToolManager group, so all cursor
    // positions must be in building-local space. Wall/ceiling/item-surface strategies return
    // world-space cursor positions (from their event.position); convert them here.
    const worldToBuildingLocal = (x: number, y: number, z: number): Vector3 => {
      const buildingId = useViewer.getState().selection.buildingId
      const buildingMesh = buildingId ? sceneRegistry.nodes.get(buildingId as AnyNodeId) : null
      return buildingMesh ? buildingMesh.worldToLocal(new Vector3(x, y, z)) : new Vector3(x, y, z)
    }

    const applyTransition = (result: TransitionResult) => {
      Object.assign(placementState.current, result.stateUpdate)
      gridPosition.current.set(...result.gridPosition)

      const c = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(c.x, c.y, c.z)
      if (result.cursorRotation) {
        cursorGroupRef.current.rotation.set(...result.cursorRotation)
      } else {
        cursorGroupRef.current.rotation.set(0, result.cursorRotationY, 0)
      }

      const draft = draftNode.current
      if (draft) {
        // Update ref for validation — no store update during drag
        Object.assign(draft, result.nodeUpdate)
      }
      revalidate()
    }

    const ensureDraft = (result: TransitionResult) => {
      gridPosition.current.set(...result.gridPosition)
      const c = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(c.x, c.y, c.z)
      if (result.cursorRotation) {
        cursorGroupRef.current.rotation.set(...result.cursorRotation)
      } else {
        cursorGroupRef.current.rotation.set(0, result.cursorRotationY, 0)
      }

      const initRotation: [number, number, number] = result.cursorRotation ?? [
        0,
        result.cursorRotationY,
        0,
      ]

      draftNode.create(gridPosition.current, asset, initRotation, configRef.current.defaultScale)

      const draft = draftNode.current
      if (draft) {
        Object.assign(draft, result.nodeUpdate)
        // One-time setup: put node in the right parent so it renders correctly
        useScene.getState().updateNode(draft.id, result.nodeUpdate)
      }

      const previewBounds = expandBoundsToGrid(
        getFallbackPreviewBounds(draftNode.current, asset, asset.attachTo),
        asset.attachTo,
        gridSnapStep,
      )
      updatePreviewGeometry(previewBounds)
      updateDimensionGuides(previewBounds)

      if (!revalidate()) {
        draftNode.destroy()
      }
    }

    // ---- Init draft ----
    configRef.current.initDraft(gridPosition.current)

    // Sync cursor to the draft mesh's world position and rotation
    if (draftNode.current) {
      const mesh = sceneRegistry.nodes.get(draftNode.current.id)
      if (mesh) {
        const worldPos = new Vector3()
        mesh.getWorldPosition(worldPos)
        const localPos = worldToBuildingLocal(worldPos.x, worldPos.y, worldPos.z)
        cursorGroupRef.current.position.copy(localPos)
        if (draftNode.current.asset.attachTo) {
          // Wall/ceiling items: extract world Y rotation (handles wall-parented items correctly)
          const q = new Quaternion()
          mesh.getWorldQuaternion(q)
          cursorGroupRef.current.rotation.y = new Euler().setFromQuaternion(q, 'YXZ').y
        } else {
          // Floor items: the cursor group lives in building-local space, so use the
          // node's local Y rotation — the same value onGridMove applies. The world
          // quaternion would double-count any building rotation, leaving the initial
          // box mis-rotated until the first cursor move.
          cursorGroupRef.current.rotation.y = draftNode.current.rotation[1] ?? 0
        }
      } else {
        cursorGroupRef.current.position.copy(gridPosition.current)
        cursorGroupRef.current.rotation.y = draftNode.current.rotation[1] ?? 0
      }
    }

    revalidate()

    // ---- Floor Handlers ----

    let previousGridPos: [number, number, number] | null = null

    const onGridMove = (event: GridEvent) => {
      // Lazy draft creation: if no draft yet (e.g. level wasn't ready during init), create now
      if (draftNode.current === null && asset.attachTo === undefined) {
        configRef.current.initDraft(gridPosition.current)
      }

      has3DPointerDrivenMoveRef.current = true
      lastRawPos.current.set(event.localPosition[0], event.localPosition[1], event.localPosition[2])
      const result = floorStrategy.move(getContext(), event)
      if (!result) return

      // Play snap sound when grid position changes
      if (
        previousGridPos &&
        (result.gridPosition[0] !== previousGridPos[0] ||
          result.gridPosition[2] !== previousGridPos[2])
      ) {
        sfxEmitter.emit('sfx:grid-snap')
      }

      previousGridPos = [...result.gridPosition]
      gridPosition.current.set(...result.gridPosition)
      cursorGroupRef.current.position.set(
        result.cursorPosition[0],
        result.cursorPosition[1],
        result.cursorPosition[2],
      )
      // Floor items only rotate on Y; keep the preview box (and the live
      // transform the 2D floorplan mirrors) aligned with the draft's
      // rotation. Without this the box stays at its seed rotation until a
      // manual R/T, so a moved already-rotated item shows an axis-aligned box.
      cursorGroupRef.current.rotation.y = result.cursorRotationY

      const draft = draftNode.current
      if (draft) draft.position = result.gridPosition

      // Publish live transform for 2D floorplan
      if (draft) {
        useLiveTransforms.getState().set(draft.id, {
          position: result.gridPosition,
          rotation: cursorGroupRef.current.rotation.y,
        })
      }

      revalidate()
    }

    const onGridClick = (event: GridEvent) => {
      const result = floorStrategy.click(getContext(), event, getActiveValidators())
      if (!result) return

      // Preserve cursor rotation for the next draft
      const currentRotation: [number, number, number] = [0, cursorGroupRef.current.rotation.y, 0]

      // Clear live transform before commit
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }

      draftNode.commit(result.nodeUpdate)
      if (configRef.current.onCommitted()) {
        draftNode.create(gridPosition.current, asset, currentRotation)
        const previewBounds = expandBoundsToGrid(
          getFallbackPreviewBounds(draftNode.current, asset, asset.attachTo),
          asset.attachTo,
          gridSnapStep,
        )
        updatePreviewGeometry(previewBounds)
        updateDimensionGuides(previewBounds)
        revalidate()
      }
    }

    // ---- Wall Handlers ----

    const onWallEnter = (event: WallEvent) => {
      has3DPointerDrivenMoveRef.current = true
      const nodes = useScene.getState().nodes
      const result = wallStrategy.enter(
        getContext(),
        event,
        resolveLevelId,
        nodes,
        getActiveValidators(),
      )
      if (!result) return

      event.stopPropagation()
      applyTransition(result)

      if (!draftNode.current) {
        ensureDraft(result)
      } else if (result.nodeUpdate.parentId) {
        // Existing draft (move mode): reparent to new wall
        useScene.getState().updateNode(draftNode.current.id, result.nodeUpdate)
        if (result.stateUpdate.wallId) {
          useScene.getState().dirtyNodes.add(result.stateUpdate.wallId as AnyNodeId)
        }
      }
    }

    const onWallMove = (event: WallEvent) => {
      has3DPointerDrivenMoveRef.current = true
      const ctx = getContext()

      if (ctx.state.surface !== 'wall') {
        const nodes = useScene.getState().nodes
        const enterResult = wallStrategy.enter(
          ctx,
          event,
          resolveLevelId,
          nodes,
          getActiveValidators(),
        )
        if (!enterResult) return

        event.stopPropagation()
        applyTransition(enterResult)
        if (draftNode.current && enterResult.nodeUpdate.parentId) {
          useScene.getState().updateNode(draftNode.current.id, enterResult.nodeUpdate)
          if (enterResult.stateUpdate.wallId) {
            useScene.getState().dirtyNodes.add(enterResult.stateUpdate.wallId as AnyNodeId)
          }
        }
        return
      }

      if (!draftNode.current) {
        const nodes = useScene.getState().nodes
        const setup = wallStrategy.enter(
          getContext(),
          event,
          resolveLevelId,
          nodes,
          getActiveValidators(),
        )
        if (!setup) return

        event.stopPropagation()
        ensureDraft(setup)
        return
      }

      const result = wallStrategy.move(ctx, event, getActiveValidators())
      if (!result) return

      event.stopPropagation()

      const posChanged =
        gridPosition.current.x !== result.gridPosition[0] ||
        gridPosition.current.y !== result.gridPosition[1] ||
        gridPosition.current.z !== result.gridPosition[2]

      // Play snap sound when grid position changes
      if (posChanged) {
        sfxEmitter.emit('sfx:grid-snap')
      }

      gridPosition.current.set(...result.gridPosition)
      const wc = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(wc.x, wc.y, wc.z)
      cursorGroupRef.current.rotation.y = result.cursorRotationY

      const draft = draftNode.current
      if (draft && result.nodeUpdate) {
        if ('side' in result.nodeUpdate) draft.side = result.nodeUpdate.side
        if ('rotation' in result.nodeUpdate)
          draft.rotation = result.nodeUpdate.rotation as [number, number, number]
      }

      const placeable = revalidate()

      if (draft && placeable) {
        draft.position = result.gridPosition
        const mesh = sceneRegistry.nodes.get(draft.id)
        if (mesh) {
          mesh.position.copy(gridPosition.current)
          const rot = result.nodeUpdate?.rotation
          if (rot) mesh.rotation.y = rot[1]

          // Push wall-side items out by half the parent wall's thickness
          if (asset.attachTo === 'wall-side' && placementState.current.wallId) {
            const parentWall = useScene.getState().nodes[placementState.current.wallId as AnyNodeId]
            if (parentWall?.type === 'wall') {
              const wallThickness = (parentWall as WallNode).thickness ?? 0.1
              mesh.position.z = (wallThickness / 2) * (draft.side === 'front' ? 1 : -1)
            }
          }
        }
        // Mark parent wall dirty so it rebuilds geometry — only when position changed
        if (result.dirtyNodeId && posChanged) {
          const now = globalThis.performance?.now?.() ?? Date.now()
          const last = lastWallDirtyAtRef.current.get(result.dirtyNodeId) ?? 0
          // Wall rebuilds can trigger expensive CSG; throttle live previews to avoid FPS collapse.
          if (now - last > 120) {
            lastWallDirtyAtRef.current.set(result.dirtyNodeId, now)
            useScene.getState().dirtyNodes.add(result.dirtyNodeId)
          }
        }

        // Publish live transform for 2D floorplan
        useLiveTransforms.getState().set(draft.id, {
          position: result.cursorPosition,
          rotation: result.cursorRotationY,
        })
      }
    }

    const onWallClick = (event: WallEvent) => {
      const result = wallStrategy.click(getContext(), event, getActiveValidators())
      if (!result) return

      event.stopPropagation()
      // Clear live transform before commit
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }
      draftNode.commit(result.nodeUpdate)
      if (result.dirtyNodeId) {
        useScene.getState().dirtyNodes.add(result.dirtyNodeId)
      }

      if (configRef.current.onCommitted()) {
        const nodes = useScene.getState().nodes
        const enterResult = wallStrategy.enter(
          getContext(),
          event,
          resolveLevelId,
          nodes,
          validators,
        )
        if (enterResult) {
          applyTransition(enterResult)
        } else {
          revalidate()
        }
      }
    }

    const onWallLeave = (event: WallEvent) => {
      const result = wallStrategy.leave(getContext())
      if (!result) return

      event.stopPropagation()

      if (asset.attachTo) {
        if (draftNode.isAdopted) {
          // Move mode: keep draft alive, reparent to level
          const oldWallId = placementState.current.wallId
          applyTransition(result)
          const draft = draftNode.current
          if (draft) {
            useScene
              .getState()
              .updateNode(draft.id, { parentId: result.nodeUpdate.parentId as string })
          }
          if (oldWallId) {
            useScene.getState().dirtyNodes.add(oldWallId as AnyNodeId)
          }
        } else {
          // Create mode: destroy transient and reset state
          draftNode.destroy()
          Object.assign(placementState.current, result.stateUpdate)
        }
      } else {
        applyTransition(result)
      }
    }

    // ---- Item Surface Handlers ----

    const detachItemSurfaceToFloor = (event: ItemEvent) => {
      const buildingLocalPoint = worldToBuildingLocal(
        event.position[0],
        event.position[1],
        event.position[2],
      )
      const wx = Math.round(buildingLocalPoint.x * 2) / 2
      const wz = Math.round(buildingLocalPoint.z * 2) / 2
      const floorPos: [number, number, number] = [wx, 0, wz]

      Object.assign(placementState.current, { surface: 'floor', surfaceItemId: null })
      gridPosition.current.set(wx, 0, wz)
      cursorGroupRef.current.position.set(wx, 0, wz)

      const draft = draftNode.current
      if (draft) {
        draft.position = floorPos
        useScene.getState().updateNode(draft.id, {
          parentId: useViewer.getState().selection.levelId as string,
          position: floorPos,
        })
      }

      revalidate()
    }

    const onItemEnter = (event: ItemEvent) => {
      if (event.node.id === draftNode.current?.id) return
      has3DPointerDrivenMoveRef.current = true
      const result = itemSurfaceStrategy.enter(getContext(), event)
      if (!result) return

      event.stopPropagation()
      applyTransition(result)

      if (!draftNode.current) {
        ensureDraft(result)
      } else if (result.nodeUpdate.parentId) {
        // Existing draft (move mode): reparent to surface item
        useScene.getState().updateNode(draftNode.current.id, result.nodeUpdate)
      }
    }

    const onItemMove = (event: ItemEvent) => {
      if (event.node.id === draftNode.current?.id) return
      has3DPointerDrivenMoveRef.current = true
      const ctx = getContext()

      if (ctx.state.surface !== 'item-surface') {
        // Try entering surface mode
        const enterResult = itemSurfaceStrategy.enter(ctx, event)
        if (!enterResult) return

        event.stopPropagation()
        applyTransition(enterResult)
        if (draftNode.current && enterResult.nodeUpdate.parentId) {
          useScene.getState().updateNode(draftNode.current.id, enterResult.nodeUpdate)
        }
        return
      }

      if (ctx.state.surface === 'item-surface' && event.node.id !== ctx.state.surfaceItemId) {
        const enterResult = itemSurfaceStrategy.enter(
          { ...ctx, state: { ...ctx.state, surface: 'floor', surfaceItemId: null } },
          event,
        )

        event.stopPropagation()
        if (enterResult) {
          applyTransition(enterResult)
          if (draftNode.current && enterResult.nodeUpdate.parentId) {
            useScene.getState().updateNode(draftNode.current.id, enterResult.nodeUpdate)
          }
        } else {
          detachItemSurfaceToFloor(event)
        }
        return
      }

      if (!draftNode.current) {
        const enterResult = itemSurfaceStrategy.enter(getContext(), event)
        if (!enterResult) return
        event.stopPropagation()
        ensureDraft(enterResult)
        return
      }

      lastRawPos.current.set(event.position[0], event.position[1], event.position[2])
      const result = itemSurfaceStrategy.move(ctx, event)
      if (!result) return

      event.stopPropagation()

      gridPosition.current.set(...result.gridPosition)
      const ic = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(ic.x, ic.y, ic.z)
      cursorGroupRef.current.rotation.y = result.cursorRotationY

      const draft = draftNode.current
      if (draft) {
        draft.position = result.gridPosition
        const mesh = sceneRegistry.nodes.get(draft.id)
        if (mesh) mesh.position.set(...result.gridPosition)

        // Publish live transform for 2D floorplan
        useLiveTransforms.getState().set(draft.id, {
          position: result.cursorPosition,
          rotation: result.cursorRotationY,
        })
      }

      revalidate()
    }

    const onItemLeave = (event: ItemEvent) => {
      if (event.node.id === draftNode.current?.id) return
      if (placementState.current.surface !== 'item-surface') return

      event.stopPropagation()

      // `event.localPosition` from useNodeEvents is in the LEAVING item's
      // local space (the sofa/table the draft is detaching from), not
      // building-local. Convert from world via worldToBuildingLocal instead,
      // otherwise the wireframe jumps to a surface-local-coordinate ghost
      // position until the next mouse move.
      detachItemSurfaceToFloor(event)
    }

    const onItemClick = (event: ItemEvent) => {
      // Click on the draft item itself. R3F dispatches click events to
      // the closest intersected mesh only — when the draft is hovering
      // on a host (shelf / table / etc.) the draft's mesh is *above*
      // the host's mesh, so the host's `${kind}:click` never fires.
      // If we're currently hosting on a shelf-surface, treat the
      // self-click as a commit on the active shelf so the user doesn't
      // have to aim around the cursor preview to drop the item.
      if (event.node.id === draftNode.current?.id) {
        const ctx = getContext()
        if (ctx.state.surface === 'shelf-surface' && ctx.state.shelfId) {
          const shelfNode = useScene.getState().nodes[ctx.state.shelfId as AnyNodeId]
          if (shelfNode && shelfNode.type === 'shelf') {
            const synthetic = { ...event, node: shelfNode } as unknown as ItemEvent
            const result = shelfSurfaceStrategy.click(ctx, synthetic as never)
            if (result) {
              event.stopPropagation()
              if (draftNode.current) {
                useLiveTransforms.getState().clear(draftNode.current.id)
              }
              draftNode.commit(result.nodeUpdate)
              if (configRef.current.onCommitted()) {
                const enterResult = shelfSurfaceStrategy.enter(ctx, synthetic as never)
                if (enterResult) {
                  applyTransition(enterResult)
                } else {
                  revalidate()
                }
              }
              return
            }
          }
        }
        // Same self-click forwarding for item-surface hosts (tables,
        // counters) — the draft mesh sits on top of the host mesh, so
        // the host's own click event is blocked by the cursor preview.
        if (ctx.state.surface === 'item-surface' && ctx.state.surfaceItemId) {
          const hostNode = useScene.getState().nodes[ctx.state.surfaceItemId as AnyNodeId]
          if (hostNode && hostNode.type === 'item') {
            const synthetic = { ...event, node: hostNode } as ItemEvent
            const result = itemSurfaceStrategy.click(ctx, synthetic)
            if (result) {
              event.stopPropagation()
              if (draftNode.current) {
                useLiveTransforms.getState().clear(draftNode.current.id)
              }
              draftNode.commit(result.nodeUpdate)
              if (configRef.current.onCommitted()) {
                const enterResult = itemSurfaceStrategy.enter(ctx, synthetic)
                if (enterResult) {
                  applyTransition(enterResult)
                } else {
                  revalidate()
                }
              }
              return
            }
          }
        }
        // Ceiling-hosted draft: when placing a ceiling-attached item the
        // draft hangs below the ceiling and intercepts the click ray
        // before the ceiling-grid mesh does — so `ceiling:click` never
        // fires and the user's commit click is dropped. Forward the
        // self-click to `ceilingStrategy.click` so placement commits the
        // same way it would from a click on the ceiling itself.
        if (ctx.state.surface === 'ceiling' && ctx.state.ceilingId) {
          const ceilingNode = useScene.getState().nodes[ctx.state.ceilingId as AnyNodeId]
          if (ceilingNode && ceilingNode.type === 'ceiling') {
            const synthetic = { ...event, node: ceilingNode } as unknown as CeilingEvent
            const result = ceilingStrategy.click(ctx, synthetic, getActiveValidators())
            if (result) {
              event.stopPropagation()
              if (draftNode.current) {
                useLiveTransforms.getState().clear(draftNode.current.id)
              }
              draftNode.commit(result.nodeUpdate)
              if (configRef.current.onCommitted()) {
                const nodes = useScene.getState().nodes
                const enterResult = ceilingStrategy.enter(
                  getContext(),
                  synthetic,
                  resolveLevelId,
                  nodes,
                )
                if (enterResult) {
                  applyTransition(enterResult)
                } else {
                  revalidate()
                }
              }
              return
            }
          }
        }
        return
      }

      const result = itemSurfaceStrategy.click(getContext(), event)
      if (!result) return

      event.stopPropagation()
      // Clear live transform before commit
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }
      draftNode.commit(result.nodeUpdate)

      if (configRef.current.onCommitted()) {
        // Try to set up next draft on the same surface
        const enterResult = itemSurfaceStrategy.enter(getContext(), event)
        if (enterResult) {
          applyTransition(enterResult)
        } else {
          revalidate()
        }
      }
    }

    // ---- Ceiling Handlers ----

    const onCeilingEnter = (event: CeilingEvent) => {
      has3DPointerDrivenMoveRef.current = true
      const nodes = useScene.getState().nodes
      const result = ceilingStrategy.enter(getContext(), event, resolveLevelId, nodes)
      if (!result) return

      event.stopPropagation()
      applyTransition(result)

      if (!draftNode.current) {
        ensureDraft(result)
      } else if (result.nodeUpdate.parentId) {
        // Existing draft (move mode): reparent to new ceiling
        useScene.getState().updateNode(draftNode.current.id, result.nodeUpdate)
        if (result.stateUpdate.ceilingId) {
          useScene.getState().dirtyNodes.add(result.stateUpdate.ceilingId as AnyNodeId)
        }
      }
    }

    const onCeilingMove = (event: CeilingEvent) => {
      has3DPointerDrivenMoveRef.current = true
      if (!draftNode.current && placementState.current.surface === 'ceiling') {
        const nodes = useScene.getState().nodes
        const setup = ceilingStrategy.enter(getContext(), event, resolveLevelId, nodes)
        if (!setup) return

        event.stopPropagation()
        ensureDraft(setup)
        return
      }

      lastRawPos.current.set(event.localPosition[0], event.localPosition[1], event.localPosition[2])
      const result = ceilingStrategy.move(getContext(), event)
      if (!result) return

      event.stopPropagation()

      // Play snap sound when grid position changes
      const posChanged =
        gridPosition.current.x !== result.gridPosition[0] ||
        gridPosition.current.y !== result.gridPosition[1] ||
        gridPosition.current.z !== result.gridPosition[2]

      if (posChanged) {
        sfxEmitter.emit('sfx:grid-snap')
      }

      gridPosition.current.set(...result.gridPosition)
      const cc = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(cc.x, cc.y, cc.z)

      revalidate()

      const draft = draftNode.current
      if (draft) {
        draft.position = result.gridPosition
        const mesh = sceneRegistry.nodes.get(draft.id)
        if (mesh) mesh.position.copy(gridPosition.current)

        // Publish live transform for 2D floorplan
        useLiveTransforms.getState().set(draft.id, {
          position: result.cursorPosition,
          rotation: cursorGroupRef.current.rotation.y,
        })
      }
    }

    const onCeilingClick = (event: CeilingEvent) => {
      const result = ceilingStrategy.click(getContext(), event, getActiveValidators())
      if (!result) return

      event.stopPropagation()
      // Clear live transform before commit
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }
      draftNode.commit(result.nodeUpdate)

      if (configRef.current.onCommitted()) {
        const nodes = useScene.getState().nodes
        const enterResult = ceilingStrategy.enter(getContext(), event, resolveLevelId, nodes)
        if (enterResult) {
          applyTransition(enterResult)
        } else {
          revalidate()
        }
      }
    }

    const onCeilingLeave = (event: CeilingEvent) => {
      const result = ceilingStrategy.leave(getContext())
      if (!result) return

      event.stopPropagation()

      if (asset.attachTo) {
        if (draftNode.isAdopted) {
          // Move mode: keep draft alive, reparent to level
          const oldCeilingId = placementState.current.ceilingId
          applyTransition(result)
          const draft = draftNode.current
          if (draft) {
            useScene
              .getState()
              .updateNode(draft.id, { parentId: result.nodeUpdate.parentId as string })
          }
          if (oldCeilingId) {
            useScene.getState().dirtyNodes.add(oldCeilingId as AnyNodeId)
          }
        } else {
          // Create mode: destroy transient and reset state
          draftNode.destroy()
          Object.assign(placementState.current, result.stateUpdate)
        }
      } else {
        applyTransition(result)
      }
    }

    // ---- Shelf Handlers ----
    //
    // Items can host on shelves the same way they host on tables and
    // counters (item-surface). The shelf's `surfaces.custom` exposes one
    // candidate Y per row; `shelfSurfaceStrategy` picks the closest one
    // to the cursor's local-Y so the user can target a specific row.

    const onShelfEnter = (event: ShelfEvent) => {
      has3DPointerDrivenMoveRef.current = true
      const result = shelfSurfaceStrategy.enter(getContext(), event)
      if (!result) return

      event.stopPropagation()
      applyTransition(result)

      if (!draftNode.current) {
        ensureDraft(result)
      } else if (result.nodeUpdate.parentId) {
        useScene.getState().updateNode(draftNode.current.id, result.nodeUpdate)
      }
    }

    const onShelfMove = (event: ShelfEvent) => {
      has3DPointerDrivenMoveRef.current = true
      const ctx = getContext()
      if (ctx.state.surface !== 'shelf-surface') {
        // Cursor entered via a move event without an enter — try
        // transitioning in so the user doesn't need to mouse out + back
        // in to start hosting.
        const enterResult = shelfSurfaceStrategy.enter(ctx, event)
        if (!enterResult) return
        event.stopPropagation()
        applyTransition(enterResult)
        if (!draftNode.current) {
          ensureDraft(enterResult)
        } else if (enterResult.nodeUpdate.parentId) {
          useScene.getState().updateNode(draftNode.current.id, enterResult.nodeUpdate)
        }
        return
      }
      const result = shelfSurfaceStrategy.move(ctx, event)
      if (!result) return

      event.stopPropagation()

      gridPosition.current.set(...result.gridPosition)
      const ic = worldToBuildingLocal(...result.cursorPosition)
      cursorGroupRef.current.position.set(ic.x, ic.y, ic.z)
      cursorGroupRef.current.rotation.y = result.cursorRotationY

      const draft = draftNode.current
      if (draft) {
        draft.position = result.gridPosition
        const mesh = sceneRegistry.nodes.get(draft.id)
        if (mesh) mesh.position.set(...result.gridPosition)
        useLiveTransforms.getState().set(draft.id, {
          position: result.cursorPosition,
          rotation: result.cursorRotationY,
        })
      }

      revalidate()
    }

    const onShelfLeave = (event: ShelfEvent) => {
      if (placementState.current.surface !== 'shelf-surface') return
      if (event.node.id !== placementState.current.shelfId) return
      event.stopPropagation()
      // Drop back to floor — same pattern as item-leave but without the
      // detachItemSurfaceToFloor (no scaled rotation hand-off to deal
      // with since the shelf rotation already composed cleanly).
      Object.assign(placementState.current, { surface: 'floor', shelfId: null })
    }

    const onShelfClick = (event: ShelfEvent) => {
      const result = shelfSurfaceStrategy.click(getContext(), event)
      if (!result) return

      event.stopPropagation()
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }
      draftNode.commit(result.nodeUpdate)

      if (configRef.current.onCommitted()) {
        const enterResult = shelfSurfaceStrategy.enter(getContext(), event)
        if (enterResult) {
          applyTransition(enterResult)
        } else {
          revalidate()
        }
      }
    }

    // ---- Keyboard rotation ----

    const ROTATION_STEP = Math.PI / 2
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Shift') {
        shiftFreeRef.current = true
        revalidate()
        return
      }

      // Don't intercept keys when focus is inside a text input
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
        return
      }

      const draft = draftNode.current
      if (!draft) return

      let rotationDelta = 0
      if ((event.key === 'r' || event.key === 'R') && !event.metaKey && !event.ctrlKey)
        rotationDelta = ROTATION_STEP
      else if ((event.key === 't' || event.key === 'T') && !event.metaKey && !event.ctrlKey)
        rotationDelta = -ROTATION_STEP

      if (rotationDelta !== 0) {
        event.preventDefault()
        sfxEmitter.emit('sfx:item-rotate')
        const currentRotation = draft.rotation
        const newRotationY = (currentRotation[1] ?? 0) + rotationDelta
        draft.rotation = [currentRotation[0], newRotationY, currentRotation[2]]

        // Ref + cursor mesh + item mesh — no store update during drag
        cursorGroupRef.current.rotation.y = newRotationY
        const mesh = sceneRegistry.nodes.get(draft.id)
        if (mesh) mesh.rotation.y = newRotationY

        // Re-snap position immediately with updated rotation (dimX/dimZ may swap at 90°)
        const surface = placementState.current.surface
        if (surface === 'floor' || surface === 'ceiling') {
          const dims = getScaledDimensions(draft)
          const [dimX, , dimZ] = dims
          const swapDims = Math.abs(Math.sin(newRotationY)) > 0.9
          const x = snapToGrid(lastRawPos.current.x, swapDims ? dimZ : dimX)
          const z = snapToGrid(lastRawPos.current.z, swapDims ? dimX : dimZ)
          gridPosition.current.set(x, gridPosition.current.y, z)
          draft.position = [x, gridPosition.current.y, z]
          cursorGroupRef.current.position.x = x
          cursorGroupRef.current.position.z = z
          if (mesh) {
            mesh.position.x = x
            mesh.position.z = z
          }
        } else if (surface === 'item-surface' && placementState.current.surfaceItemId) {
          const surfaceMesh = sceneRegistry.nodes.get(placementState.current.surfaceItemId)
          if (surfaceMesh) {
            const localPos = surfaceMesh.worldToLocal(lastRawPos.current.clone())
            const dims = getScaledDimensions(draft)
            const [dimX, , dimZ] = dims
            const swapDims = Math.abs(Math.sin(newRotationY)) > 0.9
            const x = snapToGrid(localPos.x, swapDims ? dimZ : dimX)
            const z = snapToGrid(localPos.z, swapDims ? dimX : dimZ)
            const y = gridPosition.current.y
            gridPosition.current.set(x, y, z)
            draft.position = [x, y, z]
            const worldSnapped = surfaceMesh.localToWorld(new Vector3(x, y, z))
            const localSnapped = worldToBuildingLocal(
              worldSnapped.x,
              worldSnapped.y,
              worldSnapped.z,
            )
            cursorGroupRef.current.position.set(localSnapped.x, localSnapped.y, localSnapped.z)
            if (mesh) mesh.position.set(x, y, z)
          }
        }

        // Update live transform for 2D floorplan with post-snap position
        const currentLive = useLiveTransforms.getState().get(draft.id)
        if (currentLive) {
          useLiveTransforms.getState().set(draft.id, {
            ...currentLive,
            position: [
              cursorGroupRef.current.position.x,
              cursorGroupRef.current.position.y,
              cursorGroupRef.current.position.z,
            ] as [number, number, number],
            rotation: newRotationY,
          })
        }

        revalidate()
      }
    }

    const onKeyUp = (event: KeyboardEvent) => {
      if (event.key === 'Shift') {
        shiftFreeRef.current = false
        revalidate()
      }
    }

    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)

    // ---- tool:cancel (Escape / programmatic) ----
    const onCancel = () => {
      if (configRef.current.onCancel) {
        configRef.current.onCancel()
      }
    }
    emitter.on('tool:cancel', onCancel)

    // ---- Right-click cancel ----
    const onContextMenu = (event: MouseEvent) => {
      if (configRef.current.onCancel) {
        event.preventDefault()
        configRef.current.onCancel()
      }
    }
    window.addEventListener('contextmenu', onContextMenu)

    // ---- Bounding box geometry ----
    // Always derive the wireframe from `asset.dimensions × scale` rather than
    // the rendered mesh bounds. Asset dimensions describe the item's footprint
    // (e.g. only the trunk for a palm tree), while the mesh bbox would include
    // foliage or other visual overhang the snap logic intentionally ignores.

    const draft = draftNode.current
    const previewBounds = expandBoundsToGrid(
      getFallbackPreviewBounds(draft, asset, asset.attachTo),
      asset.attachTo,
      gridSnapStep,
    )
    updatePreviewGeometry(previewBounds)
    updateDimensionGuides(previewBounds)

    // ---- Undo protection ----
    // Undo replaces the entire `nodes` object with a previous snapshot, which doesn't
    // include the draft (created while temporal was paused). Re-insert it so the mesh
    // doesn't disappear mid-placement.
    // We defer via queueMicrotask to avoid nested setState during the undo callback.
    // Temporal is already paused during placement, so createNode won't enter the undo stack.
    let tearingDown = false
    const unsubDraftWatch = useScene.subscribe((state) => {
      if (tearingDown) return
      const draft = draftNode.current
      if (draft === null) return
      if (draft.id in state.nodes) return

      queueMicrotask(() => {
        if (tearingDown) return
        const draft = draftNode.current
        if (draft === null) return
        if (draft.id in useScene.getState().nodes) return
        // Temporal is paused during placement, createNode won't be tracked
        useScene.getState().createNode(draft, draft.parentId as AnyNodeId)
      })
    })

    // ---- Subscribe ----

    emitter.on('grid:move', onGridMove)
    emitter.on('grid:click', onGridClick)
    emitter.on('item:enter', onItemEnter)
    emitter.on('item:move', onItemMove)
    emitter.on('item:leave', onItemLeave)
    emitter.on('item:click', onItemClick)
    emitter.on('wall:enter', onWallEnter)
    emitter.on('wall:move', onWallMove)
    emitter.on('wall:click', onWallClick)
    emitter.on('wall:leave', onWallLeave)
    emitter.on('ceiling:enter', onCeilingEnter)
    emitter.on('ceiling:move', onCeilingMove)
    emitter.on('ceiling:click', onCeilingClick)
    emitter.on('ceiling:leave', onCeilingLeave)
    emitter.on('shelf:enter', onShelfEnter)
    emitter.on('shelf:move', onShelfMove)
    emitter.on('shelf:click', onShelfClick)
    emitter.on('shelf:leave', onShelfLeave)

    return () => {
      tearingDown = true
      unsubDraftWatch()
      // Clear live transform for any remaining draft
      if (draftNode.current) {
        useLiveTransforms.getState().clear(draftNode.current.id)
      }
      draftNode.destroy()
      useScene.temporal.getState().resume()
      emitter.off('grid:move', onGridMove)
      emitter.off('grid:click', onGridClick)
      emitter.off('item:enter', onItemEnter)
      emitter.off('item:move', onItemMove)
      emitter.off('item:leave', onItemLeave)
      emitter.off('item:click', onItemClick)
      emitter.off('wall:enter', onWallEnter)
      emitter.off('wall:move', onWallMove)
      emitter.off('wall:click', onWallClick)
      emitter.off('wall:leave', onWallLeave)
      emitter.off('ceiling:enter', onCeilingEnter)
      emitter.off('ceiling:move', onCeilingMove)
      emitter.off('ceiling:click', onCeilingClick)
      emitter.off('ceiling:leave', onCeilingLeave)
      emitter.off('shelf:enter', onShelfEnter)
      emitter.off('shelf:move', onShelfMove)
      emitter.off('shelf:click', onShelfClick)
      emitter.off('shelf:leave', onShelfLeave)
      emitter.off('tool:cancel', onCancel)
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      window.removeEventListener('contextmenu', onContextMenu)
    }
  }, [
    asset,
    canPlaceOnFloor,
    canPlaceOnWall,
    canPlaceOnCeiling,
    draftNode,
    gridSnapStep,
    updateDimensionGuides,
    updatePreviewGeometry,
  ])

  // Refresh wireframe when the grid step changes mid-placement so the green/red
  // box snaps to the new cell size right away.
  useEffect(() => {
    if (!asset) return
    const draft = draftNode.current
    const previewBounds = expandBoundsToGrid(
      getFallbackPreviewBounds(draft, asset, asset.attachTo),
      asset.attachTo,
      gridSnapStep,
    )
    updatePreviewGeometry(previewBounds)
    updateDimensionGuides(previewBounds)
  }, [gridSnapStep, asset, draftNode, updateDimensionGuides, updatePreviewGeometry])
  // Wall/ceiling items are managed by their own surface entry events (ensureDraft / reparent).
  const viewerLevelId = useViewer((s) => s.selection.levelId)
  useEffect(() => {
    if (!asset) return
    const draft = draftNode.current
    if (!(draft && viewerLevelId) || asset.attachTo) return
    if (draft.parentId === viewerLevelId) return
    draft.parentId = viewerLevelId
    useScene.getState().updateNode(draft.id as AnyNodeId, { parentId: viewerLevelId })
  }, [viewerLevelId, draftNode, asset])

  useFrame((_, delta) => {
    if (!asset) return
    if (!draftNode.current) return
    // The mesh-position lerp below only makes sense once this coordinator
    // owns the move via a 3D pointer event. Skip until then so that
    // external drivers (e.g. the 2D `FloorplanRegistryMoveOverlay`
    // writing scene.position directly) aren't fought by useFrame pulling
    // the mesh back to its pre-move location.
    if (!has3DPointerDrivenMoveRef.current) return
    const mesh = sceneRegistry.nodes.get(draftNode.current.id)
    if (!mesh) return

    // Hide wall/ceiling-attached items when between surfaces (only cursor visible)
    if (asset.attachTo && placementState.current.surface === 'floor') {
      mesh.visible = false
      return
    }
    mesh.visible = true

    if (placementState.current.surface === 'floor') {
      const distance = mesh.position.distanceToSquared(gridPosition.current)
      if (distance > 1) {
        mesh.position.copy(gridPosition.current)
      } else {
        mesh.position.lerp(gridPosition.current, delta * 20)
      }

      // Adjust Y for slab elevation (floor items on top of slabs)
      if (!asset.attachTo) {
        const nodes = useScene.getState().nodes
        const levelId = resolveLevelId(draftNode.current, nodes)
        const slabElevation = spatialGridManager.getSlabElevationForItem(
          levelId,
          [gridPosition.current.x, gridPosition.current.y, gridPosition.current.z],
          getGridAlignedDimensions(
            getScaledDimensions(draftNode.current),
            draftNode.current.asset.attachTo,
          ),
          draftNode.current.rotation,
        )
        mesh.position.y = slabElevation
      }
    }
  })

  const initialDraft = draftNode.current
  const initialAttachTo = config.asset?.attachTo
  const rawDims = initialDraft
    ? getScaledDimensions(initialDraft)
    : (config.asset?.dimensions ?? DEFAULT_DIMENSIONS)
  const dims = getGridAlignedDimensions(rawDims, initialAttachTo, gridSnapStep)
  const wallSideZOffset = initialAttachTo === 'wall-side' ? -dims[2] / 2 : 0
  const initialDimensionBounds = expandBoundsToGrid(
    getFallbackPreviewBounds(initialDraft, config.asset, initialAttachTo),
    initialAttachTo,
    gridSnapStep,
  )
  const initialEdgeGeometry = useMemo(
    () => createLineGeometry(getBoxEdgePoints(initialDimensionBounds)),
    [
      initialDimensionBounds.center[0],
      initialDimensionBounds.center[1],
      initialDimensionBounds.center[2],
      initialDimensionBounds.dimensions[0],
      initialDimensionBounds.dimensions[1],
      initialDimensionBounds.dimensions[2],
      initialDimensionBounds,
    ],
  )
  const basePlaneGeometry = useMemo(() => {
    const geometry = new PlaneGeometry(dims[0], dims[2])
    geometry.rotateX(-Math.PI / 2)
    geometry.translate(0, 0.01, wallSideZOffset)
    return geometry
  }, [dims[0], dims[2], wallSideZOffset])
  const initialWidthGuideGeometry = useMemo(() => createLineGeometry(), [])
  const initialDepthGuideGeometry = useMemo(() => createLineGeometry(), [])
  const initialHeightGuideGeometry = useMemo(() => createLineGeometry(), [])
  const currentDimensionBounds = dimensionBounds ?? initialDimensionBounds
  const widthLabel = formatMeasurement(currentDimensionBounds.dimensions[0], unit)
  const depthLabel = formatMeasurement(currentDimensionBounds.dimensions[2], unit)
  const heightLabel = formatMeasurement(currentDimensionBounds.dimensions[1], unit)
  const widthLabelPosition: [number, number, number] = [
    currentDimensionBounds.center[0],
    0.04,
    currentDimensionBounds.center[2] + currentDimensionBounds.dimensions[2] / 2 + 0.24,
  ]
  const depthLabelPosition: [number, number, number] = [
    currentDimensionBounds.center[0] + currentDimensionBounds.dimensions[0] / 2 + 0.24,
    0.04,
    currentDimensionBounds.center[2],
  ]
  const heightLabelPosition: [number, number, number] = [
    currentDimensionBounds.center[0] - currentDimensionBounds.dimensions[0] / 2 - 0.24,
    currentDimensionBounds.dimensions[1] / 2,
    currentDimensionBounds.center[2] - currentDimensionBounds.dimensions[2] / 2,
  ]

  const measurementContent = (
    <>
      <lineSegments
        geometry={initialWidthGuideGeometry}
        layers={EDITOR_LAYER}
        material={measurementMaterial}
        ref={measurementWidthRef}
        renderOrder={998}
      />
      <lineSegments
        geometry={initialDepthGuideGeometry}
        layers={EDITOR_LAYER}
        material={measurementMaterial}
        ref={measurementDepthRef}
        renderOrder={998}
      />
      <lineSegments
        geometry={initialHeightGuideGeometry}
        layers={EDITOR_LAYER}
        material={measurementMaterial}
        ref={measurementHeightRef}
        renderOrder={998}
      />
      <Html center position={widthLabelPosition} style={{ pointerEvents: 'none' }}>
        <div
          style={{
            background: 'rgba(15, 23, 42, 0.86)',
            border: '1px solid rgba(15, 23, 42, 0.65)',
            borderRadius: '999px',
            color: '#f8fafc',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: '11px',
            fontWeight: 600,
            lineHeight: 1,
            padding: '4px 8px',
            pointerEvents: 'none',
            whiteSpace: 'nowrap',
          }}
        >
          {widthLabel}
        </div>
      </Html>
      <Html center position={depthLabelPosition} style={{ pointerEvents: 'none' }}>
        <div
          style={{
            background: 'rgba(15, 23, 42, 0.86)',
            border: '1px solid rgba(15, 23, 42, 0.65)',
            borderRadius: '999px',
            color: '#f8fafc',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: '11px',
            fontWeight: 600,
            lineHeight: 1,
            padding: '4px 8px',
            pointerEvents: 'none',
            whiteSpace: 'nowrap',
          }}
        >
          {depthLabel}
        </div>
      </Html>
      <Html center position={heightLabelPosition} style={{ pointerEvents: 'none' }}>
        <div
          style={{
            background: 'rgba(15, 23, 42, 0.86)',
            border: '1px solid rgba(15, 23, 42, 0.65)',
            borderRadius: '999px',
            color: '#f8fafc',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: '11px',
            fontWeight: 600,
            lineHeight: 1,
            padding: '4px 8px',
            pointerEvents: 'none',
            whiteSpace: 'nowrap',
          }}
        >
          {heightLabel}
        </div>
      </Html>
    </>
  )

  return (
    <group ref={cursorGroupRef}>
      <lineSegments
        geometry={initialEdgeGeometry}
        layers={EDITOR_LAYER}
        material={edgeMaterial}
        ref={edgesRef}
        renderOrder={999}
      />
      {measurementContent}
      <mesh
        geometry={basePlaneGeometry}
        layers={EDITOR_LAYER}
        material={basePlaneMaterial}
        ref={basePlaneRef}
        renderOrder={999}
      />
    </group>
  )
}
