export { buildingDefinition } from './definition'
