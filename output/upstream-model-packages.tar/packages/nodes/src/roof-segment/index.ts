export { roofSegmentDefinition } from './definition'
